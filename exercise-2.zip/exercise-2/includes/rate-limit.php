<?php

defined('ABSPATH') || exit;

function check_rate_limit($ip)
{
    $key = 'lead_submit_' . md5($ip);

    $attempts = (int) get_transient($key);

    if ($attempts >= 3) {
        return false;
    }

    set_transient($key, $attempts + 1, HOUR_IN_SECONDS);

    return true;
}