<?php

defined('ABSPATH') || exit;

function validate_lead_data($data)
{
    if (empty($data['full_name']) || empty($data['email'])) {
        return [
            'success' => false,
            'message' => 'Name and email are required.'
        ];
    }

    if (!is_email($data['email'])) {
        return [
            'success' => false,
            'message' => 'Invalid email format.'
        ];
    }

    return [
        'success' => true
    ];
}