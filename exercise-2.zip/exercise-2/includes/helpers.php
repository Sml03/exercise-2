<?php

defined('ABSPATH') || exit;

function format_phone_e164($phone)
{
    $digits = preg_replace('/\D+/', '', $phone);

    if (strlen($digits) === 10) {
        return '+1' . $digits;
    }

    if (strlen($digits) === 11 && substr($digits, 0, 1) === '1') {
        return '+' . $digits;
    }

    return $phone;
}