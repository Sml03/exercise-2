<?php

defined('ABSPATH') || exit;

function store_backup_lead($table_name, $data, $error_type)
{
    global $wpdb;

    $wpdb->insert(
        $table_name,
        [
            'full_name'    => $data['full_name'],
            'email'        => $data['email'],
            'phone'        => $data['phone'],
            'company'      => $data['company'],
            'message'      => $data['message'],
            'utm_source'   => $data['utm_source'],
            'utm_medium'   => $data['utm_medium'],
            'utm_campaign' => $data['utm_campaign'],
            'error_type'   => $error_type,
            'created_at'   => current_time('mysql')
        ]
    );
}