<?php

defined('ABSPATH') || exit;

function log_api_error($message)
{
    error_log('[HubSpot API Error] ' . $message);
}