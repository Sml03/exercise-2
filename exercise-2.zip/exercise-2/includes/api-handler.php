<?php

defined('ABSPATH') || exit;

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/validation.php';
require_once __DIR__ . '/rate-limit.php';
require_once __DIR__ . '/backup-storage.php';
require_once __DIR__ . '/logger.php';

add_action('rest_api_init', function () {

    register_rest_route('custom/v1', '/lead-submit', [
        'methods'  => 'POST',
        'callback' => 'handle_hubspot_lead_submission',
        'permission_callback' => '__return_true'
    ]);
});

function handle_hubspot_lead_submission(WP_REST_Request $request)
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'backup_leads';

    $ip_address = $_SERVER['REMOTE_ADDR'];

    if (!check_rate_limit($ip_address)) {

        return new WP_REST_Response([
            'success' => false,
            'error_code' => 'RATE_LIMIT_EXCEEDED',
            'message' => 'Too many requests.'
        ], 429);
    }

    $data = [
        'full_name'    => sanitize_text_field($request->get_param('full_name')),
        'email'        => sanitize_email($request->get_param('email')),
        'phone'        => sanitize_text_field($request->get_param('phone')),
        'company'      => sanitize_text_field($request->get_param('company')),
        'message'      => sanitize_textarea_field($request->get_param('message')),
        'utm_source'   => sanitize_text_field($request->get_param('utm_source')),
        'utm_medium'   => sanitize_text_field($request->get_param('utm_medium')),
        'utm_campaign' => sanitize_text_field($request->get_param('utm_campaign')),
        'website'      => sanitize_text_field($request->get_param('website'))
    ];

    if (!empty($data['website'])) {

        return new WP_REST_Response([
            'success' => false,
            'error_code' => 'SPAM_DETECTED',
            'message' => 'Spam detected.'
        ], 400);
    }

    $validation = validate_lead_data($data);

    if (!$validation['success']) {

        return new WP_REST_Response([
            'success' => false,
            'error_code' => 'VALIDATION_ERROR',
            'message' => $validation['message']
        ], 422);
    }

    $formatted_phone = format_phone_e164($data['phone']);

    $name_parts = explode(' ', trim($data['full_name']), 2);

    $firstname = $name_parts[0] ?? '';
    $lastname  = $name_parts[1] ?? '';

    $payload = [
        'properties' => [
            [
                'property' => 'email',
                'value' => $data['email']
            ],
            [
                'property' => 'firstname',
                'value' => $firstname
            ],
            [
                'property' => 'lastname',
                'value' => $lastname
            ],
            [
                'property' => 'phone',
                'value' => $formatted_phone
            ],
            [
                'property' => 'company',
                'value' => $data['company']
            ],
            [
                'property' => 'message',
                'value' => $data['message']
            ],
            [
                'property' => 'utm_source',
                'value' => $data['utm_source']
            ],
            [
                'property' => 'utm_medium',
                'value' => $data['utm_medium']
            ],
            [
                'property' => 'utm_campaign',
                'value' => $data['utm_campaign']
            ]
        ]
    ];

    $response = wp_remote_post(
        'https://api.hubapi.com/contacts/v1/contact',
        [
            'method' => 'POST',
            'headers' => [
                'Authorization' => 'Bearer ' . HUBSPOT_PRIVATE_APP_TOKEN,
                'Content-Type' => 'application/json'
            ],
            'body' => wp_json_encode($payload),
            'timeout' => 20
        ]
    );

    if (is_wp_error($response)) {

        store_backup_lead($table_name, $data, 'wp_error');

        log_api_error($response->get_error_message());

        return new WP_REST_Response([
            'success' => false,
            'error_code' => 'CRM_UNAVAILABLE',
            'message' => 'Lead stored temporarily.'
        ], 503);
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);

    if ($status_code >= 200 && $status_code < 300) {

        return new WP_REST_Response([
            'success' => true,
            'lead_id' => $body['vid'] ?? null,
            'message' => 'Lead submitted successfully.'
        ], 200);
    }

    store_backup_lead($table_name, $data, 'hubspot_api_failed');

    log_api_error('HubSpot API failed with status ' . $status_code);

    return new WP_REST_Response([
        'success' => false,
        'error_code' => 'HUBSPOT_API_FAILED',
        'message' => 'Submission received. We will process it shortly.'
    ], 500);
}
